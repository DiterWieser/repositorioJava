/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
@Entity
@Table(name = "Cliente")
public class Cliente implements Comparable<Cliente>, Serializable{
    
    @Id
    @GeneratedValue
    @Column(name = "idCliente")
    private int id;
    
    @Column(name = "nomeCliente", length = 100)
    private String nome;
    
    @Column(name = "cpf", length = 15)
    private String cpf;
    
    @Column(name = "dataNascimento")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dataNascimento;
    
    @Column(name = "fone", length = 11)
    private String fone;
    
    @Column(name = "celular", length = 11)
    private String celular;
    
    @Column(name = "eMail")
    private String eMail;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @Column(name = "idEndereco")
    private Endereco endereco;

    public Cliente() {
    }

    public Cliente(String nome, String cpf, Date dataNascimento, String fone, String celular, String eMail, Endereco endereco) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.fone = fone;
        this.celular = celular;
        this.eMail = eMail;
        this.endereco = endereco;
    }

    public Cliente(int id, String nome, String cpf, Date dataNascimento, String fone, String celular, String eMail, Endereco endereco) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.fone = fone;
        this.celular = celular;
        this.eMail = eMail;
        this.endereco = endereco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.nome);
        hash = 23 * hash + Objects.hashCode(this.cpf);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.cpf, other.cpf)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        if(fone != null)
            return nome + ". CPF:  " + cpf + ". Telefone: " + fone;
        if(celular != null)
            return nome + ". CPF:  " + cpf + ". Celular: " + celular;
        return nome + ". CPF:  " + cpf;
    }

    @Override
    public int compareTo(Cliente cliente) {
        int comparacao;
        
        comparacao = this.nome.compareToIgnoreCase(cliente.nome);
        if(comparacao != 0)
            return comparacao;
        
        try {
            int este = Integer.parseInt(this.cpf);
            int outro = Integer.parseInt(cliente.cpf);
            return este - outro;
        } catch(ClassCastException exc) {
            return this.cpf.compareTo(cliente.cpf);
        }
    }
    
}
