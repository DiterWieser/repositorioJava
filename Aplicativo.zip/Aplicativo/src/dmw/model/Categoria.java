/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
@Entity
@Table(name = "Categoria")
public class Categoria implements Comparable<Categoria>, Serializable {
    
    @Id
    @GeneratedValue
    @Column(name = "idCategoria")
    private int id;
    
    @Column(name = "nomeCategoria")
    private String nome;

    public Categoria() {
    }

    public Categoria(String nome) {
        this.nome = nome;
    }

    public Categoria(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.nome);
        return hash;
    }

    @Override
    public boolean equals(Object objetivo) {
        if (objetivo == null) {
            return false;
        }
        if (getClass() != objetivo.getClass()) {
            return false;
        }
        final Categoria other = (Categoria) objetivo;
        return Objects.equals(this.nome, other.nome);
    }

    @Override
    public String toString() {
        return nome;
    }

    @Override
    public int compareTo(Categoria categoria) {
        return this.nome.compareToIgnoreCase(categoria.nome);
    }
    
}
