/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.dao;

import dmw.model.Categoria;
import dmw.util.ConectaHibernate;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
public class CategoriaDAO extends AbstractDAO<Categoria>{

    @Override
    public List<Categoria> listar() {
        Session sessao;
        Transaction transacao;
        Criteria consulta;
        List<Categoria> categorias;
        
        sessao = ConectaHibernate.getSessao();
        transacao = sessao.beginTransaction();
        consulta = sessao.createCriteria(Categoria.class);
        categorias = consulta.list();
        transacao.commit();
        sessao.close();
        return categorias;
    }

    @Override
    public Categoria buscar(int id) {
        Session sessao;
        Transaction transacao;
        Criteria consulta;
        Categoria categoria;
        
        sessao = ConectaHibernate.getSessao();
        transacao = sessao.beginTransaction();
        consulta = sessao.createCriteria(Categoria.class);
        consulta.add(Restrictions.eq("id", id));
        categoria = (Categoria) consulta.uniqueResult();
        transacao.commit();
        sessao.close();
        return categoria;
    }
    
}
