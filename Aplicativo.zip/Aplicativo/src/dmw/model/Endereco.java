/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
@Entity
@Table(name = "Endereco")
public class Endereco implements Comparable<Endereco>, Serializable{
    
    @Id
    @GeneratedValue
    @Column(name = "idEndereco")
    private int id;
    
    @Column(name = "logradouro", length = 100)
    private String logradouro;
    
    @Column(name = "numero")
    private int numero;
    
    @Column(name = "complemento", length = 100)
    private String complemento;
    
    @Column(name = "bairro", length = 50)
    private String bairro;
    
    @Column(name = "cep", length = 8)
    private String cep;
    
    @Column(name = "cidade", length = 100)
    private String cidade;

    public Endereco() {
    }

    public Endereco(String logradouro, int numero, String complemento, String bairro, String cep, String cidade) {
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cep = cep;
        this.cidade = cidade;
    }

    public Endereco(int id, String logradouro, int numero, String complemento, String bairro, String cep, String cidade) {
        this.id = id;
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cep = cep;
        this.cidade = cidade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + Objects.hashCode(this.logradouro);
        hash = 67 * hash + this.numero;
        hash = 67 * hash + Objects.hashCode(this.complemento);
        hash = 67 * hash + Objects.hashCode(this.bairro);
        hash = 67 * hash + Objects.hashCode(this.cidade);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Endereco other = (Endereco) obj;
        if (!Objects.equals(this.logradouro, other.logradouro)) {
            return false;
        }
        if (this.numero != other.numero) {
            return false;
        }
        if (!Objects.equals(this.complemento, other.complemento)) {
            return false;
        }
        if (!Objects.equals(this.bairro, other.bairro)) {
            return false;
        }
        return Objects.equals(this.cidade, other.cidade);
    }

    @Override
    public int compareTo(Endereco endereco) {
        int comparacao = this.cidade.compareToIgnoreCase(endereco.cidade);
        if(comparacao != 0)
            return comparacao;
        
        comparacao = this.bairro.compareToIgnoreCase(endereco.bairro);
        if(comparacao != 0)
            return comparacao;
        
        comparacao = this.logradouro.compareToIgnoreCase(endereco.logradouro);
        if(comparacao != 0)
            return comparacao;
        
        comparacao = this.numero - endereco.numero;
        if(comparacao != 0)
            return comparacao;
        
        return this.complemento.compareToIgnoreCase(endereco.complemento);
    }
    
}
