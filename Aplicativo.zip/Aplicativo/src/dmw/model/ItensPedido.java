/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.model;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
@Entity
@Table(name = "ItemPedido")
public class ItensPedido implements Comparable<ItensPedido>, Serializable {
    
    @Id
    @GeneratedValue
    @Column(name = "idItemPedido")
    private int id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "idPedido")
    private Pedido pedido;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "idProduto")
    private Produto produto;
    
    @Column(name = "quantidade")
    private int quantidade;
    
    @Transient
    private BigDecimal total;

    public ItensPedido() {
    }

    public ItensPedido(Pedido pedido, Produto produto, int quantidade) {
        this.pedido = pedido;
        this.produto = produto;
        this.quantidade = quantidade;
        calcularTotal();
    }

    public ItensPedido(int id, Pedido pedido, Produto produto, int quantidade) {
        this.id = id;
        this.pedido = pedido;
        this.produto = produto;
        this.quantidade = quantidade;
        calcularTotal();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
        calcularTotal();
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
        if(produto != null)
            calcularTotal();
    }

    private void calcularTotal() {
        this.total = produto.getPreco().multiply(new BigDecimal(this.quantidade));
    }
    
    public BigDecimal getTotal() {
        return total;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItensPedido other = (ItensPedido) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return produto + " x " + quantidade +  " = R$ " + total;
    }

    @Override
    public int compareTo(ItensPedido pedido) {
        return this.produto.compareTo(pedido.produto);
    }
    
}
