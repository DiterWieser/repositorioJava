/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.dao;

import dmw.util.ConectaHibernate;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Diter Martim Wieser
 * @param <E>
 * @since 24/05/2016
 */
public abstract class AbstractDAO<E> {
    
    public void salvar(E e) {
        Session sessao;
        Transaction transacao;
        
        sessao = ConectaHibernate.getSessao();
        transacao = sessao.beginTransaction();
        sessao.save(e);
        transacao.commit();
        sessao.close();
    }
    
    public void apagar(E e) {
        Session sessao;
        Transaction transacao;
        
        sessao = ConectaHibernate.getSessao();
        transacao = sessao.beginTransaction();
        sessao.delete(e);
        transacao.commit();
        sessao.close();
    }
    
    public abstract List<E> listar();
    public abstract E buscar(int id);
    
}
