/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
public class ConectaHibernate {
    private static SessionFactory fabricaSessoes;
    
    private static void criarSessionFactory() {
        Configuration config = new Configuration();
        config.configure();
        ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
        fabricaSessoes = config.buildSessionFactory(serviceRegistry);
    }
    
    public static Session getSessao(){
        if(fabricaSessoes == null)
            criarSessionFactory();
        if(fabricaSessoes.getCurrentSession() == null)
            return fabricaSessoes.openSession();
        return fabricaSessoes.getCurrentSession();
    }
    
}
