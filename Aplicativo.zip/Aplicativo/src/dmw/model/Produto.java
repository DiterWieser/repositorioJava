/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
@Entity
@Table(name = "Produto")
public class Produto implements Comparable<Produto>, Serializable {
    
    @Id
    @GeneratedValue
    @Column(name = "idProduto")
    private int id;
    
    @Column(name = "nomeProduto", length = 100)
    private String nome;
    
    @Column(name = "preco", length = 12, precision = 2)
    private BigDecimal preco;
    
    @Column(name = "descricao")
    private String descricao;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "idCategoria")
    private Categoria categoria;

    public Produto() {
    }

    public Produto(String nome, BigDecimal preco, String descricao, Categoria categoria) {
        this.nome = nome;
        this.preco = preco;
        this.descricao = descricao;
        this.categoria = categoria;
    }

    public Produto(String nome, double preco, String descricao, Categoria categoria) {
        this.nome = nome;
        this.preco = new BigDecimal(preco);
        this.descricao = descricao;
        this.categoria = categoria;
    }

    public Produto(String nome, int preco, String descricao, Categoria categoria) {
        this.nome = nome;
        this.preco = new BigDecimal(preco);
        this.descricao = descricao;
        this.categoria = categoria;
    }

    public Produto(int id, String nome, BigDecimal preco, String descricao, Categoria categoria) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.descricao = descricao;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public void setPreco(double preco) {
        this.preco = new BigDecimal(preco);
    }
    
    public void setPreco(int preco) {
        this.preco = new BigDecimal(preco);
    }
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + Objects.hashCode(this.nome);
        hash = 47 * hash + Objects.hashCode(this.preco);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        return Objects.equals(this.preco, other.preco);
    }

    @Override
    public String toString() {
        return nome + ". R$ " + preco;
    }

    @Override
    public int compareTo(Produto produto) {
        int comparacao = this.nome.compareToIgnoreCase(produto.nome);
        if(comparacao != 0)
            return comparacao;
        
        return this.preco.compareTo(produto.preco);
    }

}
