/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dmw.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

/**
 *
 * @author Diter Martim Wieser
 * @since 24/05/2016
 */
@Entity
@Table(name = "Pedido")
public class Pedido implements Comparable<Pedido>, Serializable {
    
    @Id
    @GeneratedValue
    @Column(name = "idPedido")
    private int id;
    
    @Column(name = "dataPedido")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dataPedido;
    
    @Column(name = "aberto")
    private boolean aberto;
    
    @Column(name = "mesa", length = 20)
    private String mesa;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "idCliente")
    private Cliente cliente;
    
    public Pedido() {
    }

    public Pedido(Date dataPedido, Cliente cliente, String mesa) {
        this.dataPedido = dataPedido;
        this.aberto = true;
        this.cliente = cliente;
        this.mesa = mesa;
    }

    public Pedido(int id, Date dataPedido, boolean aberto, Cliente cliente, String mesa) {
        this.id = id;
        this.dataPedido = dataPedido;
        this.aberto = aberto;
        this.cliente = cliente;
        this.mesa = mesa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(Date dataPedido) {
        this.dataPedido = dataPedido;
    }

    public boolean isAberto() {
        return aberto;
    }

    public void setAberto(boolean aberto) {
        this.aberto = aberto;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getMesa() {
        return mesa;
    }

    public void setMesa(String mesa) {
        this.mesa = mesa;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        return this.id == other.id;
    }

    @Override
    public int compareTo(Pedido pedido) {
        return this.id - pedido.id;
    }
    
}
